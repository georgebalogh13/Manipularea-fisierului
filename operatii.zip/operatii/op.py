f = open("operatii.txt", "r")
    
def performOperation(a,op,b):
    if op is "+":
        return a + b
    elif op is "-":
        return a - b
    elif op is "/":
        return a / b
    else:
        return a * b

def operation(line):
    line = line.strip()
    operationWithResult =""
    index = -1
    i = 0
    for c in line:
        if c is "+" or c is "-" or c is "/" or c is "*":
            index = i 
        i = i + 1
    firstNumber = line[0: index]
    secondNumber = line[index + 1: ]
    op = line[index:index+1]
    operationResult = performOperation(int(firstNumber), op, int(secondNumber))
    operationWithResult += str(firstNumber + op + secondNumber + "="  + str(operationResult)) + "\n"
    return operationWithResult

resultFileContent = ""
for line in f:
  res = operation(line)
  resultFileContent = resultFileContent + res

print(resultFileContent)

f = open("result.txt", "w")
f.write(resultFileContent)

f.close()